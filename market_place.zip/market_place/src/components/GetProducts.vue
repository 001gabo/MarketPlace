<template>
  <div>
      <h1>Productos disponibles</h1>
      <table class="table">
        <thead>
            <tr>
            <th scope="col">{{info.data.results.company}}</th>
            <th scope="col">{{info.productTitle}}</th>
            <th scope="col">{{info.description}}</th>
            <th scope="col">{{info.regularPrice}}</th>
            </tr>
        </thead>
        <tbody>

        </tbody>
      </table>
  </div>
</template>

<script>
import axios from 'axios'
export default {
  name: 'GetProducts',
  props:["getproducts"],
   data(){
            return{
            info: null
            }
        },
    mounted() {
        axios
            .get('https://private-1cbd79-marketplaceapi25.apiary-mock.com/marketplace')
            .then(response => (this.info = response))
        }
    }

</script>

<style lang="stylus" scoped>

</style>
