<template>
  <div id="app">
    <GetProducts/>
  </div>
</template>

<script>
import GetProducts from './components/GetProducts.vue'

export default {
  name: 'app',
  components: {
    GetProducts
  }
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
